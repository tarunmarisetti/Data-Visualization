let originalData;
// This function is called once the HTML page is fully loaded by the browser
document.addEventListener('DOMContentLoaded', function () {
    // Load the CSV file
    d3.csv('superheroes_final.csv')
        .then(function (data) {
            console.log('Loaded the data');
            originalData = data.map(d => {
                d.first_appearance_year = +d.first_appearance_year ? +d.first_appearance_year : 1990;
                d.intelligence = +d.intelligence;
                d.strength = +d.strength;
                d.speed = +d.speed;
                d.durability = +d.durability;
                d.power = +d.power;
                d.combat = +d.combat;
                d.interesting_facts = d.interesting_facts;
                d.alliances = d.alliances ? d.alliances : 'no Alliances';
                d.relatives = d.relatives ? d.relatives : 'no Relatives';
                d.group_affiliation = d['group-affiliation'] ? d['group-affiliation'] : 'no Group Affiliation';
                
                // Initialize events with detailed data points
                d.events = [
                    {
                        type: "full_name_or_aka",
                        description: `Full Name: ${d['full-name'] || 'Unknown'}, AKA: ${d.aliases || 'None'}`
                    },
                    {
                        type: "physical_appearance",
                        description: `
                            Gender: ${d.gender || 'Unknown'}, Race: ${d.race || 'Unknown'},
                            Height: ${d.height || 'Unknown'}, Weight: ${d.weight || 'Unknown'},
                            Eye Color: ${d['eye-color'] || 'Unknown'}, Hair Color: ${d['hair-color'] || 'Unknown'}
                        `
                    },
                    {
                        type: "relatives",
                        description: `Relatives: ${d.relatives}`
                    },
                    {
                        type: "group_affiliation",
                        description: `Group Affiliation: ${d.group_affiliation}`
                    }
                ];
            
                return d;
            });
            

            populateCharacterDropdowns(originalData);
            console.log(originalData)
             // Set initial filter index to 0 for "Top 5" and call updateChartByFilter
             currentFilterIndex = 0;
             updateChartByFilter(); // Display the initial chart and description
        })
        .catch(function (error) {
            console.error('Error loading the dataset:', error);
        });
        const filterDescriptions = {
            "top5": "Meet the Top legendary characters-choosen based on their Skills.",
            "male": "Discover the MALE icons who shape the world of comics, embodying strength, courage, and influence as both heroes and villains.",
            "female": "Explore the powerful FEMALE characters who redefine heroism and villainy with unmatched style and strength.",
            "heroes": "Step into the LIGHT! Here are the HERO'S who protect the world with bravery, sacrifice, and justice.",
            "villains": "Enter the SHADOWS... these VILLAIN'S are the masterminds of chaos, challenging heroes at every turn."
        };
        
    const filterOrder = ["top5", "male", "female","villains","heroes"];
    let currentFilterIndex = 0;

function updateChartByFilter() {
    const selectedFilter = filterOrder[currentFilterIndex];
    let filteredData;

    // Filter data based on the selected filter
    if (selectedFilter === "top5") {
        originalData.sort((a, b) => b.first_appearance_year - a.first_appearance_year);
        filteredData = originalData.slice(0, 5);
    } else if (selectedFilter === "heroes") {
        filteredData = originalData.filter(d => d.alignment === "good");
    } else if (selectedFilter === "villains") {
        filteredData = originalData.filter(d => d.alignment === "bad");
    } else if (selectedFilter === "male") {
        filteredData = originalData.filter(d => d.gender === "Male");
    } else if (selectedFilter === "female") {
        filteredData = originalData.filter(d => d.gender === "Female");
    }
     // Update the description text
     typeText(filterDescriptions[selectedFilter], "filterDescription", 60);
    // Redraw chart with the filtered data
    drawChartCheck(filteredData, true);
}
document.addEventListener('mousedown', function(event) {
    if (event.button === 0) { // Left click
        // Move to the previous filter in a circular manner
        currentFilterIndex = (currentFilterIndex - 1 + filterOrder.length) % filterOrder.length;
        updateChartByFilter();
    } else if (event.button === 2) { // Right click
        // Move to the next filter in a circular manner
        currentFilterIndex = (currentFilterIndex + 1) % filterOrder.length;
        // Update the chart based on the new filter
        updateChartByFilter();
    }
    
});

// Prevent the default right-click context menu
document.addEventListener('contextmenu', function(event) {
    event.preventDefault();
});
});

function drawChartCheck(data, dataChange) {
    // Clearing the previous SVG with a fade-out transition if dataset changes
    if (dataChange) {
        d3.select("#visualization").select("svg").transition()
            .duration(500) 
            .style("opacity", 0)
            .remove()
            .end()
            .then(() => drawChart(data));
    } else {
        d3.select("#visualization").select("svg").remove();
        drawChart(data);
    }
}



function drawChart(data) {
    // Set up dimensions and margins
    const margin = { top: 20, right: 20, bottom: 45, left: 55 };
    const padding = 120;
    const rowHeight = 150;
    const containerWidth = document.getElementById("visualization").clientWidth;
    const containerHeight = data.length * rowHeight + margin.top + margin.bottom;
    const width = containerWidth - margin.left - margin.right;
    const height = containerHeight;

    // Create the SVG element
    const svg = d3.select("#visualization")
    .append("svg")
    .attr("viewBox", `0 0 ${width + margin.left + margin.right} ${height + margin.top + margin.bottom}`)
    .attr("preserveAspectRatio", "xMinYMin meet") // Maintain aspect ratio
    .attr("width", "100%") 
    .attr("height", "100%") 
    .attr("transform", `translate(${margin.left},${margin.top})`);
    
    // Define x-axis based on the range of first appearance years
    const xExtent = d3.extent(data, d => d.first_appearance_year);
    const xScale = d3.scaleLinear()
                     .domain([xExtent[0] - 5, xExtent[1] + 25])
                     .range([padding, width - padding+100]);

    const comicFont = "'Comic Sans MS', 'Comic Neue', sans-serif";

    // Define the main x-axis for major year ticks with comic styling
    const xAxis = d3.axisBottom(xScale)
        .ticks(10)
        .tickFormat(d3.format("d"))
        .tickSizeInner(25)                   
        .tickSizeOuter(25);

    // Define the minor x-axis for smaller ticks
    const xAxisMinor = d3.axisBottom(xScale)
        .ticks(100)
        .tickFormat("")
        .tickSizeInner(12)                   
        .tickSizeOuter(12);

    // Draw a horizontal baseline with a comic-style dotted line
    svg.append("line")
        .attr("x1", padding)
        .attr("x2", width - padding+100)
        .attr("y1", height - padding+20)
        .attr("y2", height - padding+20)
        .style("stroke", "#FF4500")            
        .style("stroke-width", 3)              
        .style("stroke-dasharray", "6,3");     

    // Append the main x-axis with year labels
    svg.append("g")
        .attr("transform", `translate(0, ${height - padding+20})`)
        .attr("class", "x-axis")
        .call(xAxis)
        .selectAll("text")
        .attr("dy", "1.5em")
        .style("font-size", "20px")            
        .style("fill", "#FF4500")              
        .style("font-weight", "bold")
        .style("font-family", comicFont);      

    // Append minor ticks with controlled spacing between major ticks
    svg.append("g")
        .attr("transform", `translate(0, ${height - padding+20})`)
        .attr("class", "x-axis-minor")
        .call(xAxisMinor)
        .selectAll("line")                     
        .style("stroke", "#FFA500")            
        .style("stroke-width", 1.5)            
        .style("stroke-dasharray", "4,2");    

    // Style the major tick lines specifically for comic effect
    svg.selectAll(".x-axis .tick line")
        .style("stroke", "#FF4500")            
        .style("stroke-width", 3)              
        .style("stroke-dasharray", "6,3");     

    
       // Create a group for each character
    const characterGroups = svg.selectAll(".character-group")
                                .data(data)
                                .enter()
                                .append("g")
                                .attr("class", "character-group")
                                .attr("transform", (d, i) => `translate(0, ${margin.top + i * rowHeight})`)
                                .style("opacity", 0);
    characterGroups.each(function(d, i) {
        const group = d3.select(this);
        
        // Set a delay based on the index to create sequential appearance
        group.transition()
            .delay(i * 300)
            .duration(800)
            .style("opacity", 1);

    });
    
    characterGroups.append("line")
    .attr("x1", d => xScale(d.first_appearance_year))
    .attr("x2", xScale(xExtent[1] + 20))
    .attr("y1", 10)
    .attr("y2", 10)
    .attr("stroke-width", 3)
    .attr("stroke-dasharray", "8,4") // Dashed line pattern
    .attr("class", d => (d.alignment === "good" ? "hero-line" : "villain-line"))
    .style("pointer-events", "none"); // Prevents hover events
    // Add event points along each line
    characterGroups.each(function(d) {
    const group = d3.select(this);

    // Calculate spacing for each event point along the line
    const lineLength = xScale(xExtent[1] + 20) - xScale(d.first_appearance_year);
    const spacing = lineLength / (d.events.length + 1);

    // Create a point (circle) for each event
    d.events.forEach((event, i) => {
        group.append("circle")
            .attr("cx", xScale(d.first_appearance_year) + spacing * (i + 1))
            .attr("cy", 10)
            .attr("r", 7) // Radius of the circle
            .attr("class", "event-point") // Add a class for styling
            .attr("fill", d.alignment === "good" ? "#1f77b4" : "#d62728")
            .style("cursor", "pointer")
            .on("mouseover", function(event) {
                showTooltip(event, d.events[i].description);
            })
            .on("mouseout", hideTooltip);
    });
});
// Create the tooltip div
const tooltip1 = d3.select("body").append("div")
    .attr("class", "tooltip1")
    .style("position", "absolute")
    .style("background", "rgba(0, 0, 0, 0.8)")
    .style("color", "#fff")
    .style("padding", "25px")
    .style("border-radius", "5px")
    .style("pointer-events", "none")
    .style("opacity", 0);

// Show tooltip function
function showTooltip(event, text) {
    // Parse and format the text
    const formattedText = text.split(',').map(segment => {
        const parts = segment.split(':');
        
        // Check if the segment contains both heading and value
        if (parts.length === 2) {
            const heading = parts[0].trim();
            let value = parts[1].trim();
            if (value.startsWith('[') && value.endsWith(']')) {
                try {
                    // Parsing the value as an array and remove quotes
                    const valuesArray = JSON.parse(value.replace(/'/g, '"'));
                    if (Array.isArray(valuesArray)) {
                        value = valuesArray.map(item => item.trim()).join(' / ');
                    }
                } catch (error) {
                    console.error("Error parsing array:", error);
                }
            }

            return `<strong style="color: #FF4500;">${heading}:</strong> ${value}`;
        } else {
            return segment.trim();
        }
    }).join('<br>'); // Join each formatted line with a line break

    // Display the tooltip with formatted text
    tooltip1.html(formattedText)
        .style("left", (event.pageX + 10) + "px")
        .style("top", (event.pageY - 20) + "px")
        .transition()
        .duration(200)
        .style("opacity", 0.9);
}

// Hide tooltip function
function hideTooltip() {
    tooltip1.transition()
        .duration(200)
        .style("opacity", 0);
}

    // Append image for each character
    characterGroups.append("image")
        .attr("xlink:href", d => d.url)
        .attr("x", d => xScale(d.first_appearance_year) - 80)
        .attr("y", -25)
        .attr("width", 80)
        .attr("height", 80)
        .attr("filter", d => d.alignment === "good" ? "url(#hero-glow)" : "url(#villain-shadow)")
        .on("mouseover", handleMouseOver)
        .on("mousemove", handleMouseOver)
        .on("mouseout", handleMouseOut);

    // Append name for each character
    characterGroups.append("text")
    .attr("x", d => xScale(d.first_appearance_year) - 40)
    .attr("y", 80)
    .attr("class", "label")
    .attr("text-anchor", "middle")
    .style("font-size", "22px")
    .style("font-weight", "bold")
    .style("fill", d => d.alignment === "good" ? "#1f77b4" : "#d62728") 
    .text(d => d.name);

    const tooltip = d3.select("body").append("div")
    .attr("class", "tooltip-large")
    .style("opacity", 0)
    .style("position", "absolute")
    .style("background", "rgba(0, 0, 0, 0.8)")
    .style("color", "#fff")
    .style("padding", "15px")
    .style("border-radius", "10px")
    .style("pointer-events", "none");



    // Define mouseover and mouseout functions for fading and tooltip
    function handleMouseOver(event, d) {
    // Fade out all characters except the hovered one
    characterGroups.filter(node => node !== d)
    .transition()
    .duration(100)
    .style("opacity", 0.2);

    d3.select(this).transition()
    .duration(100)
    .style("opacity", 1);

    tooltip.html(`
        <div style="font-size: 36px; text-align: center; margin-bottom: 30px; color: #FF4500; font-weight: bold; text-shadow: 2px 2px 3px rgba(0, 0, 0, 0.3); font-family: 'Comic Sans MS', 'Comic Neue', sans-serif;">
            ${d.name}
        </div>
        <div style="display: flex; justify-content: center; align-items: center; gap: 30px; padding: 20px; background-color: #FFF5E1; border: 2px solid #FF4500; border-radius: 10px; box-shadow: 4px 4px 10px rgba(0, 0, 0, 0.3);">
            <img src="${d.url}" alt="${d.name}" style="width: 250px; height: 300px; border: 2px solid #FF4500; border-radius: 8px; box-shadow: 3px 3px 8px rgba(0, 0, 0, 0.3);">
            <div style="font-size: 20px; color: #333; display: flex; flex-direction: column; gap: 10px; font-family: 'Comic Sans MS', 'Comic Neue', sans-serif;">
                <strong style="font-size: 24px; color: #FF4500; text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.2);">Skills:</strong>
                <div style="display: flex; align-items: center; gap: 10px;">
                    <span>${attributeIcons.intelligence}</span><span>Intelligence: ${d.intelligence}</span>
                </div>
                <div style="display: flex; align-items: center; gap: 10px;">
                    <span>${attributeIcons.strength}</span><span>Strength: ${d.strength}</span>
                </div>
                <div style="display: flex; align-items: center; gap: 10px;">
                    <span>${attributeIcons.speed}</span><span>Speed: ${d.speed}</span>
                </div>
                <div style="display: flex; align-items: center; gap: 10px;">
                    <span>${attributeIcons.durability}</span><span>Durability: ${d.durability}</span>
                </div>
                <div style="display: flex; align-items: center; gap: 10px;">
                    <span>${attributeIcons.power}</span><span>Power: ${d.power}</span>
                </div>
                <div style="display: flex; align-items: center; gap: 10px;">
                    <span>${attributeIcons.combat}</span><span>Combat: ${d.combat}</span>
                </div>
            </div>
        </div>
        <div style="margin-top: 20px; font-size: 20px; color: #FF4500; text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.2); font-family: 'Comic Sans MS', 'Comic Neue', sans-serif;">
            <strong style="font-size: 30px;">Do You Know?</strong>
            <div style="font-size: 22px; color: white; margin-top: 10px;">
            ${d.interesting_facts ? 
                d.interesting_facts.split('. ').map(fact => `<p style="margin: 10px 0;">⚡ ${fact.trim()}</p>`).join('') : 
                '<p>No interesting facts available.</p>'
            }
        </div>
        </div>
    `);
        
    // Adjust tooltip position dynamically to prevent off-screen issues
    const tooltipWidth = 600; 
    const tooltipHeight = 800; 

    // Get the mouse position
    let tooltipX = event.pageX + 15;
    let tooltipY = event.pageY - 15;

    // Get the viewport boundaries
    const viewportWidth = window.innerWidth;
    const viewportHeight = window.innerHeight;

    // Adjust horizontal position if tooltip overflows on the right
    if (tooltipX + tooltipWidth > viewportWidth) {
        tooltipX = event.pageX - tooltipWidth - 15;  // Place tooltip to the left
    }

    // Adjust vertical position if tooltip overflows at the bottom
    if (tooltipY + tooltipHeight > viewportHeight) {
        tooltipY = event.pageY - tooltipHeight +300;  // Place tooltip above the mouse
    }

    // Apply the adjusted position to the tooltip
    tooltip.style("left", tooltipX + "px")
        .style("top", tooltipY + "px")
        .transition()
        .duration(200)
        .style("opacity", 0.9);
    }

    function handleMouseOut() {
         // Restore the opacity of all characters and hide the tooltip
    characterGroups.transition().duration(200).style("opacity", 1);
    tooltip.transition().duration(200).style("opacity", 0);
    }

}
const attributeIcons = {
    intelligence: `<svg width="48" height="48" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" fill="#00b4d8" /><text x="12" y="16" text-anchor="middle" font-size="16" fill="#fff">🧠</text></svg>`,
    strength: `<svg width="48" height="48" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" fill="#f77f00" /><text x="12" y="16" text-anchor="middle" font-size="16" fill="#fff">💪</text></svg>`,
    speed: `<svg width="48" height="48" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" fill="#ff006e" /><text x="12" y="16" text-anchor="middle" font-size="16" fill="#fff">⚡</text></svg>`,
    durability: `<svg width="48" height="48" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" fill="#8338ec" /><text x="12" y="16" text-anchor="middle" font-size="16" fill="#fff">🛡️</text></svg>`,
    power: `<svg width="48" height="48" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" fill="#3a86ff" /><text x="12" y="16" text-anchor="middle" font-size="16" fill="#fff">✨</text></svg>`,
    combat: `<svg width="48" height="48" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" fill="#ffbe0b" /><text x="12" y="16" text-anchor="middle" font-size="16" fill="#fff">🥋</text></svg>`
};

function populateCharacterDropdowns(originalData) {
    const character1Dropdown = document.getElementById("character1");
    const character2Dropdown = document.getElementById("character2");

    // Filter good and bad characters
    const goodCharacters = originalData.filter(character => character.alignment === "good");
    const badCharacters = originalData.filter(character => character.alignment === "bad");

    // Populate the first dropdown with good characters
    goodCharacters.forEach(character => {
        const option = document.createElement("option");
        option.value = character.name;
        option.textContent = character.name;
        character1Dropdown.appendChild(option);
    });

    // Populate the second dropdown with bad characters
    badCharacters.forEach(character => {
        const option = document.createElement("option");
        option.value = character.name;
        option.textContent = character.name;
        character2Dropdown.appendChild(option);
    });
}


function startBattle() {
    const character1Select = document.getElementById("character1");
    const character2Select = document.getElementById("character2");
    const character1Name = character1Select.value;
    const character2Name = character2Select.value;

    const battleResultElement = document.getElementById("battleResult");
    const battleAnimationElement = document.getElementById("battleAnimation");
    const winnerImage = document.getElementById("winnerImage");

    // Reset previous result, animation, and effects
    battleResultElement.textContent = "";
    battleAnimationElement.style.display = "none"; 
    winnerImage.style.display = "none"; // Hide previous winner's image
    winnerImage.classList.remove("glow-effect", "dark-shadow-effect"); // Remove previous effects

    if (!character1Name || !character2Name) {
        battleResultElement.textContent = "Please select characters.";
        return;
    }

    // Show "Fighting..." animation
    battleAnimationElement.textContent = "💥 Fighting... 💥";
    battleAnimationElement.style.display = "block";

    // Calculate scores based on attributes after 2-3 seconds
    setTimeout(() => {
        battleAnimationElement.style.display = "none"; // Hide animation

        const character1 = originalData.find(c => c.name === character1Name);
        const character2 = originalData.find(c => c.name === character2Name);

        const score1 = character1.popularity_score;
        const score2 = character2.popularity_score;

        let resultText;
        let winnerCharacter;
        let victoryMessage = ""; 

        if (score1 > score2) {
            // Good wins lines
            const goodWinMessages = [
                `Justice prevails! ${character1.name} claims victory with a score of ${score1} over ${score2}! Evil stands no chance!`,
                `With unstoppable strength and courage, ${character1.name} triumphs over the villain with ${score1} vs ${score2}!`,
                `Heroic victory! ${character1.name} saves the day with a powerful score of ${score1} vs ${score2}!`,
                `The forces of good are unstoppable! ${character1.name} defeats evil with a score of ${score1} to ${score2}!`
            ];

            // Select a random message from the array
            resultText = goodWinMessages[Math.floor(Math.random() * goodWinMessages.length)];
            winnerCharacter = character1;
            victoryMessage = "Good always leads the world!";
        } else if (score2 > score1) {
            // Bad wins lines
            const badWinMessages = [
                `Darkness conquers... ${character2.name} claims a shadowy victory with a score of ${score2} over ${score1}! Heroes beware!`,
                `Evil reigns supreme as ${character2.name} crushes their opponent with a powerful score of ${score2} to ${score1}!`,
                `Villainous triumph! ${character2.name} leaves the hero defeated with ${score2} vs ${score1}. A new era of darkness dawns!`,
                `Heroes fall, villains rise! ${character2.name} seizes the victory with a score of ${score2} to ${score1}!`
            ];

            // Select a random message from the array
            resultText = badWinMessages[Math.floor(Math.random() * badWinMessages.length)];
            winnerCharacter = character2;
            victoryMessage = "We need a better hero!";
        } else {
            // Tie lines
            const tieMessages = [
                `It's an epic showdown! Both ${character1.name} and ${character2.name} fought fiercely, ending in a tie!`,
                `Neither side gives in! The battle between ${character1.name} and ${character2.name} ends in a draw. The rivalry continues!`,
                `A clash of equals! ${character1.name} and ${character2.name} leave the battlefield in a tie, their powers evenly matched!`,
                `No victor today... ${character1.name} and ${character2.name} have matched each other’s strength to a standstill!`
            ];

            // Select a random message from the array
            resultText = tieMessages[Math.floor(Math.random() * tieMessages.length)];
            winnerCharacter = null;
        }

        // Display the result
        battleResultElement.textContent = resultText;

        // Show the winner's image if there is a winner
        if (winnerCharacter) {
            console.log("Winner Image URL:", winnerCharacter.url);
            winnerImage.src = winnerCharacter.url; // Set the image source

            // Apply effects and message based on alignment
            if (winnerCharacter.alignment === "good") {
                winnerImage.classList.add("glow-effect"); 
                battleResultElement.classList.add("good-message"); 
            } else if (winnerCharacter.alignment === "bad") {
                winnerImage.classList.add("dark-shadow-effect"); 
                battleResultElement.classList.add("bad-message"); 
            }
       // Display victory message below the result
       const victoryMessageElement = document.createElement("div");
       victoryMessageElement.className = `victory-message ${winnerCharacter.alignment === "good" ? 'good-message' : 'bad-message'}`;
       victoryMessageElement.textContent = victoryMessage;
       battleResultElement.appendChild(victoryMessageElement);

       // Display the image
       winnerImage.onload = () => {
           winnerImage.style.display = "block";
       };
       winnerImage.onerror = (error) => {
           console.error("Error loading image:", error);
           winnerImage.style.display = "none"; // Hide the image on error
       };
   } else {
       winnerImage.style.display = "none"; // Hide the image in case of a tie
   }

   // Reset the dropdown selections
   character1Select.value = "";
   character2Select.value = "";

}, 2500); // 2.5 seconds delay for the "fighting" animation
}


function showBattlePage() {
    document.getElementById("battlePage").style.display = "block";
    document.getElementById("visualization").style.display = "none";
    document.getElementById("filterDescription").style.display="none";
}

function togglePage() {
    const container = document.querySelector(".myContainer");
    const visualizationPage = document.getElementById("visualization");
    const battlePage = document.getElementById("battlePage");
    const filterDescription = document.getElementById("filterDescription");
    const descriptionContainer = document.querySelector(".description-container");
    const toggleButton = document.getElementById("toggleButton");

    if (battlePage.style.display === "none") {
        // Show the battle page, hide the visualization page, update button text
        battlePage.style.display = "block";
        visualizationPage.style.display = "none";
        filterDescription.style.display = "none";
        if (descriptionContainer) {
            descriptionContainer.style.display = "none"; // Hide the description text
        }
        toggleButton.textContent = "back to stats";

        // Reduce the container size for battle view
        container.classList.add("reduced-container");
    } else {
        // Show the visualization page, hide the battle page, update button text
        battlePage.style.display = "none";
        visualizationPage.style.display = "block";
        filterDescription.style.display = "block";
        if (descriptionContainer) {
            descriptionContainer.style.display = "block"; // Show the description text
        }
        toggleButton.textContent = "1 vs 1 Battle";

        // Restore the container size for graph plot view
        container.classList.remove("reduced-container");
        const battleResultElement = document.getElementById("battleResult");
        battleResultElement.textContent = ""; // Clear previous result
    }
}

let typingInterval;
// Typing effect function for #filterDescription
function typeText(text, elementId, speed = 50) {
    const element = document.getElementById(elementId);
    element.innerHTML = ""; // Clear existing text
    let index = 0;

    if (typingInterval) {
        clearInterval(typingInterval);
    }

    // Start a new typing effect
    typingInterval = setInterval(() => {
        if (index < text.length) {
            element.innerHTML += text.charAt(index);
            index++;
        } else {
            clearInterval(typingInterval); // Stop typing once complete
        }
    }, speed);
}
